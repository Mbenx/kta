<div class="text-center">
    2014 - Alvarez.is
    <a href="index.html#" class="go-top">
        <i class="fa fa-angle-up"></i>
    </a>
</div>