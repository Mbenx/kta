<div class="row mt">
    <div class="col-md-12">
        <div class="content-panel">
            <table class="table table-striped table-advance table-hover">
                <h4><i class="fa fa-angle-right"></i> Data Kwarran</h4>
                <div class="showback">
                    <a href="?page=tambahkwarran">
                        <button type="button" class="btn btn-warning">+ Tambah Kwarran</button>
                    </a>
                </div>
                <hr>
                <?php
                include_once './views/datakwarran/tabeldata.php';
                ?>
            </table>
        </div><!-- /content-panel -->
    </div><!-- /col-md-12 -->
</div><!-- /row -->