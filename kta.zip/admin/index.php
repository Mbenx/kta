<?php
error_reporting(0);
include_once './config/core.php';
include_once './config/functioncollection.php';
include_once './config/inc.librari.php';
include_once './master.php';
?>